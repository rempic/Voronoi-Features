from setuptools import setup

setup(name='Voronoi_Features',
      version='0.1',
      description='',
      url='http://github.com/rempic/Voronoi_Features',
      author='Remigio Picone',
      author_email='remi.picone@gmail.com',
      license='',
      packages=['Voronoi_Features'],
      zip_safe=False)
